


(1)

To use the fonts in an MVC view page:

	<link rel="stylesheet" href="~/fonts/FiraSans/Fonts.css">

To use the fonts in a static HTML page:

	<link rel="stylesheet" href="/fonts/FiraSans/Fonts.css">



(2)

To include these fonts ina CSS style, use one of the following:

	font-family:Fira Sans;
	font-family:Fira Sans Condensed;
	font-family:Fira Sans Compressed;
	font-family:Fira Mono;



(3) 

Some web servers may require the set up of a server MIME type:
(Add this if the font doesn't seem to be serving correctly.)

	.woff = application/font-woff


