var offline_PageContents = `[{"Module":"m_1","Section":"s_1","Chapter":"c_1","Page":"p_1","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_1","Page":"p_2","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_1","Page":"p_3","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_1","Page":"p_4","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_1","Page":"p_5","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_2","Page":"p_6","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_2","Page":"p_7","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_2","Page":"p_8","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_2","Page":"p_9","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_3","Page":"p_10","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_3","Page":"p_11","content":""},{"Module":"m_1","Section":"s_1","Chapter":"c_3","Page":"p_12","content":""},{"Module":"m_1","Section":"s_2","Chapter":"c_4","Page":"p_13","content":""},{"Module":"m_1","Section":"s_2","Chapter":"c_4","Page":"p_14","content":""},{"Module":"m_1","Section":"s_2","Chapter":"c_4","Page":"p_15","content":""},{"Module":"m_1","Section":"s_2","Chapter":"c_4","Page":"p_16","content":""},{"Module":"m_1","Section":"s_2","Chapter":"c_4","Page":"p_17","content":""},{"Module":"m_1","Section":"s_2","Chapter":"c_5","Page":"p_18","content":""},{"Module":"m_1","Section":"s_2","Chapter":"c_5","Page":"p_19","content":""},{"Module":"m_1","Section":"s_2","Chapter":"c_5","Page":"p_20","content":""},{"Module":"m_1","Section":"s_2","Chapter":"c_5","Page":"p_21","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_6","Page":"p_22","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_6","Page":"p_23","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_7","Page":"p_24","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_7","Page":"p_25","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_7","Page":"p_26","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_7","Page":"p_27","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_7","Page":"p_28","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_7","Page":"p_29","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_7","Page":"p_30","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_8","Page":"p_31","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_8","Page":"p_32","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_8","Page":"p_33","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_8","Page":"p_34","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_8","Page":"p_35","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_8","Page":"p_36","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_8","Page":"p_37","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_9","Page":"p_38","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_9","Page":"p_39","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_9","Page":"p_40","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_10","Page":"p_41","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_10","Page":"p_42","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_10","Page":"p_43","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_10","Page":"p_44","content":""},{"Module":"m_1","Section":"s_3","Chapter":"c_10","Page":"p_45","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_11","Page":"p_46","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_11","Page":"p_47","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_11","Page":"p_48","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_11","Page":"p_49","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_11","Page":"p_50","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_12","Page":"p_51","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_12","Page":"p_52","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_12","Page":"p_53","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_12","Page":"p_54","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_13","Page":"p_55","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_13","Page":"p_56","content":""},{"Module":"m_2","Section":"s_4","Chapter":"c_13","Page":"p_57","content":""},{"Module":"m_2","Section":"s_5","Chapter":"c_14","Page":"p_58","content":""},{"Module":"m_2","Section":"s_5","Chapter":"c_14","Page":"p_59","content":""},{"Module":"m_2","Section":"s_5","Chapter":"c_14","Page":"p_60","content":""},{"Module":"m_2","Section":"s_5","Chapter":"c_14","Page":"p_61","content":""},{"Module":"m_2","Section":"s_5","Chapter":"c_14","Page":"p_62","content":""},{"Module":"m_2","Section":"s_5","Chapter":"c_15","Page":"p_63","content":""},{"Module":"m_2","Section":"s_5","Chapter":"c_15","Page":"p_64","content":""},{"Module":"m_2","Section":"s_5","Chapter":"c_15","Page":"p_65","content":""},{"Module":"m_2","Section":"s_5","Chapter":"c_15","Page":"p_66","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_16","Page":"p_67","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_16","Page":"p_68","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_17","Page":"p_69","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_17","Page":"p_70","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_17","Page":"p_71","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_17","Page":"p_72","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_17","Page":"p_73","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_17","Page":"p_74","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_17","Page":"p_75","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_18","Page":"p_76","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_18","Page":"p_77","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_18","Page":"p_78","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_18","Page":"p_79","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_18","Page":"p_80","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_18","Page":"p_81","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_18","Page":"p_82","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_19","Page":"p_83","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_19","Page":"p_84","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_19","Page":"p_85","content":""},{"Module":"m_2","Section":"s_6","Chapter":"c_20","Page":"p_86","content":""}]`;

var offline_PageGuts = [];




function loadGuts() {
offline_PageGuts.push(`<page id="p_1" type="content"><text class="header" position-x="85" position-y="15">Objective</text><text position-y="50" width="545">
                    A crewmember has medical complaints and <a href="javascript:void(0)" class="navigateTo" data-id="p_5">ultrasound</a> images of 
                    <a href="javascript:void(0)" class="definitionPopup" data-text="Bean-shaped organs at the back of the abdominal cavity in humans, one on each side of the spinal column. They maintain water and electrolyte balance and filter waste products from the blood, which are excreted as urine.">kidneys</a> 
                    and urinary bladder are necessary. <a href="#">Renal stone</a> with blockage of urine flow is suspected.
                  </text><text position-y="167" style="font-weight:bold;">
                    You will acquire ultrasound images of the right and left kidneys and two views of the urinary <a href="#">bladder.</a></text><text position-y="202">
                    Would you like to review the concepts and details of the procedure in the FOUNDATION tab?
                  </text><text position-y="220">
                    OR
                  </text><text position-y="236">
                    Go straight to the SETUP for the exam procedure?
                  </text><image position-y="" position-x="894" source="./images/ultrasound.jpg" height="691"></image></page>`);
offline_PageGuts.push(`<page id="p_2" type="content"><text>
                      snackwave
                      <b>sub-text</b>
                      burgers
                    </text></page>`);
offline_PageGuts.push(`<page id="p_3" type="content"><text>
                      snackwave
                      <i>sub-text</i>
                      burgers
                    </text><text position-x="10" position-y="10" style="bold">Letterpress</text></page>`);
offline_PageGuts.push(`<page id="p_4" type="content"><text position-x="50" position-y="130" style="bold">tote</text><text position-x="10" position-y="20">Lorem</text><text position-x="10" position-y="30">pok</text><text position-x="10" position-y="40" style="italics">typewriter</text><text position-x="10" position-y="50">offal</text><text position-x="10" position-y="60" style="bold">chartreuse</text></page>`);
offline_PageGuts.push(`<page id="p_5" type="content"><text>gastropub</text><text>tumeric</text><text>bread</text></page>`);
offline_PageGuts.push(`<page id="p_6" type="content"><text>mustache</text><text>meggings</text><text>bag.</text><text>mumblecore.</text><text>moon</text></page>`);
offline_PageGuts.push(`<page id="p_7" type="content"><text>bag.</text><text>stumptown</text><text>bread</text><text>3</text><text>swag</text><text>gluten-free</text><text>wolf</text><text>cloud</text><text>wolf</text><text>Letterpress</text></page>`);
offline_PageGuts.push(`<page id="p_8" type="content"><text>rights</text><text>wolf</text><text>Letterpress</text></page>`);
offline_PageGuts.push(`<page id="p_9" type="content"><text>moon</text><text>whatever</text></page>`);
offline_PageGuts.push(`<page id="p_10" type="content"><text>mustache</text><text>cray</text><text>stumptown</text></page>`);
offline_PageGuts.push(`<page id="p_11" type="content"><text>tote</text><text>amet</text><text>cray</text><text>bag.</text><text>snackwave</text><text>pok</text></page>`);
offline_PageGuts.push(`<page id="p_12" type="content"><text>mustache</text><text>tousled.</text><text>pok</text><text>bag.</text><text>Fingerstache</text><text>semiotics</text><text>green</text><text>gastropub</text><text>wolf</text></page>`);
offline_PageGuts.push(`<page id="p_13" type="content"><text>amet</text><text>bag.</text><text>authentic,</text><text>dolor</text><text>crucifix</text></page>`);
offline_PageGuts.push(`<page id="p_14" type="content"></page>`);
offline_PageGuts.push(`<page id="p_15" type="content"></page>`);
offline_PageGuts.push(`<page id="p_16" type="content"><text>juice</text><text>dolor</text><text>bread</text><text>moon</text><text>dolor</text><text>authentic,</text></page>`);
offline_PageGuts.push(`<page id="p_17" type="content"><text>ipsum</text><text>iPhone</text><text>tumeric</text><text>lyft</text></page>`);
offline_PageGuts.push(`<page id="p_18" type="content"><text>authentic.</text><text>neutra</text><text>meggings</text><text>juice</text><text>whatever</text><text>meggings</text><text>iPhone</text><text>ipsum</text><text>gluten-free</text><text>snackwave</text></page>`);
offline_PageGuts.push(`<page id="p_19" type="content"><text>iPhone</text><text>tousled.</text><text>swag</text><text>letterpress</text><text>gluten-free</text><text>pok</text></page>`);
offline_PageGuts.push(`<page id="p_20" type="content"><text>green</text><text>ipsum</text><text>gastropub</text></page>`);
offline_PageGuts.push(`<page id="p_21" type="content"><text>lyft</text><text>moon</text><text>meggings</text><text>meggings</text><text>chartreuse</text><text>neutra</text><text>authentic.</text></page>`);
offline_PageGuts.push(`<page id="p_22" type="content"><text>pok</text><text>mixtape</text><text>neutra</text><text>wolf</text><text>gastropub</text><text>tumeric</text><text>crucifix</text><text>pok</text><text>letterpress</text><text>moon</text></page>`);
offline_PageGuts.push(`<page id="p_23" type="content"><text>lyft</text><text>cray</text><text>amet</text><text>gastropub</text><text>mixtape</text><text>Letterpress</text><text>green</text><text>snackwave</text><text>crucifix</text></page>`);
offline_PageGuts.push(`<page id="p_24" type="content"><text>tousled.</text><text>snackwave</text></page>`);
offline_PageGuts.push(`<page id="p_25" type="content"></page>`);
offline_PageGuts.push(`<page id="p_26" type="content"><text>amet</text><text>letterpress</text><text>tousled.</text><text>letterpress</text><text>stumptown</text><text>cloud</text><text>mustache,</text><text>rights</text></page>`);
offline_PageGuts.push(`<page id="p_27" type="content"><text>Lyft</text><text>Fingerstache</text><text>letterpress</text><text>letterpress</text><text>mustache</text><text>gastropub</text><text>mustache,</text><text>dolor</text><text>pok</text><text>dolor</text></page>`);
offline_PageGuts.push(`<page id="p_28" type="content"><text>iPhone</text><text>cloud</text><text>snackwave</text></page>`);
offline_PageGuts.push(`<page id="p_29" type="content"><text>bicycle</text><text>gluten-free</text><text>bag.</text><text>moon</text><text>pok</text><text>tote</text></page>`);
offline_PageGuts.push(`<page id="p_30" type="content"><text>cloud</text><text>cloud</text><text>pok</text><text>cloud</text><text>lyft</text><text>lyft</text><text>Fingerstache</text><text>authentic,</text><text>rights</text><text>pok</text></page>`);
offline_PageGuts.push(`<page id="p_31" type="content"><text>swag</text><text>tote</text><text>bread</text><text>whatever</text><text>3</text></page>`);
offline_PageGuts.push(`<page id="p_32" type="content"><text>mustache</text><text>gastropub</text><text>crucifix</text><text>iPhone</text></page>`);
offline_PageGuts.push(`<page id="p_33" type="content"><text>pok</text><text>whatever</text></page>`);
offline_PageGuts.push(`<page id="p_34" type="content"><text>tote</text><text>iPhone</text><text>Fingerstache</text><text>Lyft</text><text>tousled.</text><text>juice</text><text>Letterpress</text><text>gluten-free</text></page>`);
offline_PageGuts.push(`<page id="p_35" type="content"><text>juice</text><text>Fingerstache</text><text>3</text><text>juice</text></page>`);
offline_PageGuts.push(`<page id="p_36" type="content"><text>gastropub</text><text>tote</text><text>green</text></page>`);
offline_PageGuts.push(`<page id="p_37" type="content"><text>Lorem</text><text>green</text></page>`);
offline_PageGuts.push(`<page id="p_38" type="content"><text>tote</text><text>moon</text></page>`);
offline_PageGuts.push(`<page id="p_39" type="content"><text>mustache</text><text>mustache,</text><text>slow-carb</text><text>stumptown</text><text>bread</text><text>bicycle</text><text>stumptown</text><text>lyft</text><text>moon</text></page>`);
offline_PageGuts.push(`<page id="p_40" type="content"></page>`);
offline_PageGuts.push(`<page id="p_41" type="content"><text>pok</text><text>snackwave</text><text>snackwave</text><text>swag</text><text>bag.</text><text>iPhone</text><text>stumptown</text><text>pok</text></page>`);
offline_PageGuts.push(`<page id="p_42" type="content"><text>letterpress</text><text>Letterpress</text><text>letterpress</text><text>offal</text><text>cloud</text><text>gastropub</text><text>slow-carb</text><text>gluten-free</text></page>`);
offline_PageGuts.push(`<page id="p_43" type="content"><text>ipsum</text><text>chartreuse</text><text>gluten-free</text><text>tote</text><text>Lorem</text><text>Lyft</text><text>moon</text></page>`);
offline_PageGuts.push(`<page id="p_44" type="content"><text>Lorem</text><text>mustache</text><text>gluten-free</text><text>iPhone</text><text>pok</text><text>mustache,</text></page>`);
offline_PageGuts.push(`<page id="p_45" type="content"><text>bag.</text><text>Lorem</text><text>gluten-free</text><text>stumptown</text><text>Letterpress</text></page>`);
offline_PageGuts.push(`<page id="p_46" type="content"><text>stumptown</text><text>pok</text><text>bicycle</text><text>lyft</text><text>cray</text></page>`);
offline_PageGuts.push(`<page id="p_47" type="content"></page>`);
offline_PageGuts.push(`<page id="p_48" type="content"><text>moon</text><text>wolf</text><text>offal</text><text>pok</text><text>semiotics</text><text>3</text><text>tousled.</text><text>offal</text></page>`);
offline_PageGuts.push(`<page id="p_49" type="content"><text>typewriter</text><text>slow-carb</text><text>Lorem</text><text>green</text><text>typewriter</text><text>lyft</text><text>moon</text><text>iPhone</text><text>green</text><text>Lyft</text></page>`);
offline_PageGuts.push(`<page id="p_50" type="content"><text>3</text><text>authentic.</text><text>snackwave</text><text>tumeric</text><text>whatever</text><text>semiotics</text><text>tote</text><text>bicycle</text></page>`);
offline_PageGuts.push(`<page id="p_51" type="content"><text>3</text><text>Letterpress</text><text>tumeric</text><text>slow-carb</text><text>dolor</text><text>cray</text><text>mumblecore.</text></page>`);
offline_PageGuts.push(`<page id="p_52" type="content"><text>stumptown</text><text>swag</text></page>`);
offline_PageGuts.push(`<page id="p_53" type="content"><text>iPhone</text><text>rights</text><text>letterpress</text><text>semiotics</text><text>whatever</text><text>wolf</text></page>`);
offline_PageGuts.push(`<page id="p_54" type="content"><text>3</text><text>wolf</text><text>amet</text><text>slow-carb</text><text>crucifix</text><text>moon</text><text>wolf</text><text>mixtape</text></page>`);
offline_PageGuts.push(`<page id="p_55" type="content"><text>stumptown</text><text>mustache</text></page>`);
offline_PageGuts.push(`<page id="p_56" type="content"><text>letterpress</text></page>`);
offline_PageGuts.push(`<page id="p_57" type="content"><text>wolf</text><text>bread</text><text>mumblecore.</text><text>Lyft</text></page>`);
offline_PageGuts.push(`<page id="p_58" type="content"></page>`);
offline_PageGuts.push(`<page id="p_59" type="content"></page>`);
offline_PageGuts.push(`<page id="p_60" type="content"><text>pok</text><text>ipsum</text><text>mumblecore.</text><text>mustache,</text><text>wolf</text><text>neutra</text><text>bicycle</text><text>iPhone</text><text>typewriter</text><text>bag.</text></page>`);
offline_PageGuts.push(`<page id="p_61" type="content"><text>lyft</text><text>rights</text><text>rights</text><text>whatever</text><text>mixtape</text><text>Letterpress</text><text>typewriter</text><text>tousled.</text></page>`);
offline_PageGuts.push(`<page id="p_62" type="content"></page>`);
offline_PageGuts.push(`<page id="p_63" type="content"><text>slow-carb</text><text>pok</text><text>pok</text><text>dolor</text><text>authentic.</text></page>`);
offline_PageGuts.push(`<page id="p_64" type="content"><text>neutra</text><text>mustache,</text><text>typewriter</text><text>swag</text><text>amet</text></page>`);
offline_PageGuts.push(`<page id="p_65" type="content"></page>`);
offline_PageGuts.push(`<page id="p_66" type="content"><text>3</text><text>gastropub</text><text>wolf</text></page>`);
offline_PageGuts.push(`<page id="p_67" type="content"><text>Letterpress</text><text>moon</text><text>wolf</text><text>ipsum</text></page>`);
offline_PageGuts.push(`<page id="p_68" type="content"><text>tousled.</text><text>mixtape</text><text>pok</text><text>ipsum</text><text>rights</text><text>pok</text><text>mumblecore.</text><text>mixtape</text><text>stumptown</text></page>`);
offline_PageGuts.push(`<page id="p_69" type="content"><text>slow-carb</text><text>letterpress</text><text>neutra</text><text>mustache,</text><text>rights</text><text>dolor</text><text>swag</text><text>Lyft</text></page>`);
offline_PageGuts.push(`<page id="p_70" type="content"></page>`);
offline_PageGuts.push(`<page id="p_71" type="content"></page>`);
offline_PageGuts.push(`<page id="p_72" type="content"><text>ipsum</text><text>mumblecore.</text><text>mustache</text></page>`);
offline_PageGuts.push(`<page id="p_73" type="content"><text>tousled.</text><text>stumptown</text><text>letterpress</text><text>authentic.</text></page>`);
offline_PageGuts.push(`<page id="p_74" type="content"><text>pok</text><text>amet</text><text>amet</text><text>mustache</text></page>`);
offline_PageGuts.push(`<page id="p_75" type="content"><text>mixtape</text><text>Lyft</text></page>`);
offline_PageGuts.push(`<page id="p_76" type="content"><text>meggings</text><text>Lyft</text><text>pok</text></page>`);
offline_PageGuts.push(`<page id="p_77" type="content"><text>lyft</text><text>gastropub</text><text>Lyft</text><text>slow-carb</text><text>typewriter</text><text>tumeric</text><text>pok</text><text>pok</text><text>gastropub</text></page>`);
offline_PageGuts.push(`<page id="p_78" type="content"><text>ipsum</text><text>iPhone</text><text>semiotics</text><text>bag.</text><text>bag.</text></page>`);
offline_PageGuts.push(`<page id="p_79" type="content"><text>pok</text><text>Lyft</text><text>Fingerstache</text><text>typewriter</text><text>letterpress</text><text>authentic.</text><text>letterpress</text><text>gastropub</text><text>crucifix</text><text>meggings</text></page>`);
offline_PageGuts.push(`<page id="p_80" type="content"><text>pok</text><text>Letterpress</text><text>bicycle</text><text>mumblecore.</text><text>rights</text></page>`);
offline_PageGuts.push(`<page id="p_81" type="content"><text>tote</text><text>gastropub</text><text>cloud</text></page>`);
offline_PageGuts.push(`<page id="p_82" type="content"><text>Lorem</text><text>green</text><text>pok</text><text>Letterpress</text><text>tote</text><text>dolor</text><text>tumeric</text><text>pok</text></page>`);
offline_PageGuts.push(`<page id="p_83" type="content"></page>`);
offline_PageGuts.push(`<page id="p_84" type="content"><text>mixtape</text><text>typewriter</text><text>Fingerstache</text><text>whatever</text><text>letterpress</text><text>authentic,</text><text>whatever</text><text>pok</text></page>`);
offline_PageGuts.push(`<page id="p_85" type="content"><text>crucifix</text><text>typewriter</text><text>pok</text></page>`);
offline_PageGuts.push(`<page id="p_86" type="content">THE END</page>`);
}
